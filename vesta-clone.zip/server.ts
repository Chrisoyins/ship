import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("shipments.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS shipments (
    id TEXT PRIMARY KEY,
    sender_name TEXT,
    sender_email TEXT,
    sender_phone TEXT,
    sender_address TEXT,
    sender_lat TEXT,
    sender_lng TEXT,
    recipient_name TEXT,
    recipient_email TEXT,
    recipient_phone TEXT,
    recipient_address TEXT,
    recipient_lat TEXT,
    recipient_lng TEXT,
    status TEXT,
    estimated_delivery TEXT,
    current_location TEXT,
    weight TEXT,
    service_type TEXT,
    shipping_cost REAL,
    payment_status TEXT,
    branch_id TEXT,
    staff_id TEXT,
    quantity INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS shipment_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_id TEXT,
    date TEXT,
    time TEXT,
    activity TEXT,
    location TEXT,
    FOREIGN KEY(shipment_id) REFERENCES shipments(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post("/api/shipments", (req, res) => {
    const { 
      sender_name, 
      sender_email = 'N/A',
      sender_phone = 'N/A',
      sender_address, 
      sender_lat = '38.0000000',
      sender_lng = '-97.0000000',
      recipient_name, 
      recipient_email = 'N/A',
      recipient_phone = 'N/A',
      recipient_address,
      recipient_lat = '38.0000000',
      recipient_lng = '-97.0000000',
      status = 'Pending',
      estimated_delivery = 'Pending Update',
      current_location = 'Origin',
      weight = '1.0 lbs',
      service_type = 'FedEx Express',
      shipping_cost = 25.00,
      payment_status = 'Paid',
      branch_id = '2',
      staff_id = '10',
      quantity = 1
    } = req.body;

    // Generate unique tracking ID: FEDEX + 8 random digits
    const id = "FED" + Math.floor(100000000 + Math.random() * 900000000).toString();

    try {
      const insertShipment = db.prepare(`
        INSERT INTO shipments (
          id, sender_name, sender_email, sender_phone, sender_address, sender_lat, sender_lng,
          recipient_name, recipient_email, recipient_phone, recipient_address, recipient_lat, recipient_lng,
          status, estimated_delivery, current_location, weight, service_type, shipping_cost, payment_status,
          branch_id, staff_id, quantity
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      insertShipment.run(
        id, sender_name, sender_email, sender_phone, sender_address, sender_lat, sender_lng,
        recipient_name, recipient_email, recipient_phone, recipient_address, recipient_lat, recipient_lng,
        status, estimated_delivery, current_location, weight, service_type, shipping_cost, payment_status,
        branch_id, staff_id, quantity
      );

      const insertHistory = db.prepare(`
        INSERT INTO shipment_history (shipment_id, date, time, activity, location)
        VALUES (?, ?, ?, ?, ?)
      `);
      const now = new Date();
      insertHistory.run(
        id, 
        now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        'Label Created',
        sender_address || 'Origin'
      );

      res.json({ id, status: 'success' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to create shipment" });
    }
  });

  app.get("/api/shipments/:id", (req, res) => {
    const { id } = req.params;
    try {
      const shipment = db.prepare("SELECT * FROM shipments WHERE id = ?").get(id) as any;
      if (!shipment) {
        return res.status(404).json({ error: "Shipment not found" });
      }

      const history = db.prepare("SELECT * FROM shipment_history WHERE shipment_id = ? ORDER BY id DESC").all(id);
      
      res.json({
        id: shipment.id,
        status: shipment.status,
        estimatedDelivery: shipment.estimated_delivery,
        currentLocation: shipment.current_location,
        sender_name: shipment.sender_name,
        sender_email: shipment.sender_email,
        sender_phone: shipment.sender_phone,
        sender_address: shipment.sender_address,
        sender_lat: shipment.sender_lat,
        sender_lng: shipment.sender_lng,
        recipient_name: shipment.recipient_name,
        recipient_email: shipment.recipient_email,
        recipient_phone: shipment.recipient_phone,
        recipient_address: shipment.recipient_address,
        recipient_lat: shipment.recipient_lat,
        recipient_lng: shipment.recipient_lng,
        weight: shipment.weight,
        service_type: shipment.service_type,
        shipping_cost: shipment.shipping_cost,
        payment_status: shipment.payment_status,
        branch_id: shipment.branch_id,
        staff_id: shipment.staff_id,
        quantity: shipment.quantity,
        created_at: shipment.created_at,
        updated_at: shipment.updated_at,
        history: history.map((h: any) => ({
          date: h.date,
          time: h.time,
          activity: h.activity,
          location: h.location
        }))
      });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/admin/shipments", (req, res) => {
    try {
      const shipments = db.prepare("SELECT * FROM shipments ORDER BY created_at DESC").all();
      res.json(shipments);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
