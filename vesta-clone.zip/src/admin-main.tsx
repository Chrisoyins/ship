import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import { db } from './firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import './index.css';

const AdminApp = () => {
  const [formData, setFormData] = useState({
    sender_name: '',
    sender_address: '',
    recipient_name: '',
    recipient_address: '',
    weight: '',
    shipping_cost: '',
    quantity: '1'
  });
  const [loading, setLoading] = useState(false);
  const [successId, setSuccessId] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Generate a tracking ID
      const trackingId = "FED" + Math.floor(100000000 + Math.random() * 900000000).toString();
      
      // WRITE to Firebase Database
      await addDoc(collection(db, "shipments"), {
        ...formData,
        trackingId,
        status: 'Pending',
        created_at: serverTimestamp(),
        updated_at: serverTimestamp()
      });

      setSuccessId(trackingId);
      setFormData({ sender_name: '', sender_address: '', recipient_name: '', recipient_address: '', weight: '', shipping_cost: '', quantity: '1' });
    } catch (error) {
      console.error("Error adding document: ", error);
      alert("Error saving to database");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-3xl shadow-xl p-8">
        <h1 className="text-3xl font-black text-[#4D148C] mb-8">Admin: Create Shipment</h1>
        
        {successId && (
          <div className="mb-8 p-6 bg-green-50 border border-green-100 rounded-2xl text-green-700 font-bold">
            Shipment Created! Tracking ID: <span className="text-green-900 underline">{successId}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase">Sender Name</label>
              <input 
                required
                className="w-full p-4 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:border-[#4D148C]"
                value={formData.sender_name}
                onChange={e => setFormData({...formData, sender_name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase">Recipient Name</label>
              <input 
                required
                className="w-full p-4 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:border-[#4D148C]"
                value={formData.recipient_name}
                onChange={e => setFormData({...formData, recipient_name: e.target.value})}
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase">Sender Address</label>
            <input 
              required
              className="w-full p-4 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:border-[#4D148C]"
              value={formData.sender_address}
              onChange={e => setFormData({...formData, sender_address: e.target.value})}
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase">Recipient Address</label>
            <input 
              required
              className="w-full p-4 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:border-[#4D148C]"
              value={formData.recipient_address}
              onChange={e => setFormData({...formData, recipient_address: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase">Weight</label>
              <input 
                required
                className="w-full p-4 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:border-[#4D148C]"
                value={formData.weight}
                onChange={e => setFormData({...formData, weight: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase">Qty</label>
              <input 
                required
                type="number"
                className="w-full p-4 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:border-[#4D148C]"
                value={formData.quantity}
                onChange={e => setFormData({...formData, quantity: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase">Cost ($)</label>
              <input 
                required
                className="w-full p-4 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:border-[#4D148C]"
                value={formData.shipping_cost}
                onChange={e => setFormData({...formData, shipping_cost: e.target.value})}
              />
            </div>
          </div>

          <button 
            disabled={loading}
            className="w-full bg-[#4D148C] text-white py-5 rounded-2xl font-black text-xl hover:bg-[#3a0f6a] transition-all disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Create Shipment'}
          </button>
        </form>
      </div>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')!).render(<AdminApp />);
