/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useNavigate 
} from 'react-router-dom';
import { 
  Search, 
  Menu, 
  X, 
  Phone, 
  Mail, 
  Truck, 
  Package, 
  Globe, 
  Clock, 
  Shield, 
  Printer, 
  ChevronDown, 
  ChevronUp,
  ArrowRight,
  MapPin,
  Map as MapIcon,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Plus,
  List,
  User,
  Settings,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
      {/* Top Bar */}
      <div className="hidden md:flex bg-[#4D148C] text-white py-2 px-4 justify-between items-center text-xs font-medium">
        <div className="flex items-center space-x-6">
          <a href="mailto:insightwebmaster@fedex.com" className="flex items-center hover:text-gray-200 transition-colors">
            <Mail className="w-3 h-3 mr-2" />
            insightwebmaster@fedex.com
          </a>
          <a href="tel:+18085633849" className="flex items-center hover:text-gray-200 transition-colors">
            <Phone className="w-3 h-3 mr-2" />
            +18085633849
          </a>
        </div>
        <div className="flex items-center space-x-4">
          <a href="#" className="hover:text-gray-200 transition-colors">Order Tracking</a>
          <span className="text-gray-400">|</span>
          <a href="#" className="hover:text-gray-200 transition-colors">Support</a>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <span className="text-3xl font-black tracking-tighter flex">
                <span className="text-[#4D148C]">Fed</span>
                <span className="text-[#FF6600]">Ex</span>
              </span>
            </div>
            <div className="hidden md:ml-10 md:flex md:space-x-8">
              <Link to="/" className="text-gray-700 hover:text-[#4D148C] px-3 py-2 text-sm font-semibold transition-colors">Home</Link>
              <a href="#" className="text-gray-700 hover:text-[#4D148C] px-3 py-2 text-sm font-semibold transition-colors">About</a>
              <a href="#" className="text-gray-700 hover:text-[#4D148C] px-3 py-2 text-sm font-semibold transition-colors">Service</a>
              <a href="#" className="text-gray-700 hover:text-[#4D148C] px-3 py-2 text-sm font-semibold transition-colors">FAQ</a>
              <Link to="/admin" className="text-gray-700 hover:text-[#4D148C] px-3 py-2 text-sm font-semibold transition-colors">Admin</Link>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <button className="bg-[#FF6600] text-white px-6 py-2.5 rounded-full font-bold text-sm hover:bg-[#e65c00] transition-all shadow-lg shadow-orange-200 flex items-center">
              Track Order
              <ArrowRight className="ml-2 w-4 h-4" />
            </button>
          </div>
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-[#4D148C] p-2"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-gray-100 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              {['Home', 'About', 'Service', 'FAQ', 'Blog', 'Contact'].map((item) => (
                <a
                  key={item}
                  href="#"
                  className="block px-3 py-4 text-base font-medium text-gray-700 hover:text-[#4D148C] hover:bg-gray-50 rounded-lg"
                >
                  {item}
                </a>
              ))}
              <div className="pt-4">
                <button className="w-full bg-[#FF6600] text-white px-6 py-3 rounded-full font-bold text-base hover:bg-[#e65c00] transition-all">
                  Track Order
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

interface TrackingStatus {
  id: string;
  status: 'In Transit' | 'Delivered' | 'Pending' | 'Exception';
  estimatedDelivery: string;
  currentLocation: string;
  sender_name?: string;
  sender_email?: string;
  sender_phone?: string;
  sender_address?: string;
  sender_lat?: string;
  sender_lng?: string;
  recipient_name?: string;
  recipient_email?: string;
  recipient_phone?: string;
  recipient_address?: string;
  recipient_lat?: string;
  recipient_lng?: string;
  weight?: string;
  service_type?: string;
  shipping_cost?: number;
  payment_status?: string;
  branch_id?: string;
  staff_id?: string;
  quantity?: number;
  created_at?: string;
  updated_at?: string;
  history: { date: string; time: string; activity: string; location: string }[];
}

const DUMMY_TRACKING_DATA: Record<string, TrackingStatus> = {
  '123456789012': {
    id: '123456789012',
    status: 'In Transit',
    estimatedDelivery: 'Tuesday, March 4 by 8:00 PM',
    currentLocation: 'Memphis, TN',
    sender_name: 'Anthony Jackson',
    sender_email: 'Anthonyjack3on@yahoo.com',
    sender_phone: '3053309854',
    sender_address: 'NW 183 St, Miami Gardens, FL 33056',
    sender_lat: '38.0000000',
    sender_lng: '-97.0000000',
    recipient_name: 'Sandra Logbo',
    recipient_email: 'sandralogbo@yahoo.com',
    recipient_phone: '+1 (973) 771-8241',
    recipient_address: 'Address: 20 Glenridge Av Apt. J 1-1 Montclair Nj 07042',
    recipient_lat: '38.0000000',
    recipient_lng: '-97.0000000',
    weight: '5.4 lbs',
    service_type: 'FedEx Priority Overnight',
    shipping_cost: 714.00,
    payment_status: 'Unpaid',
    branch_id: '2',
    staff_id: '10',
    quantity: 21,
    created_at: '2026-02-15 01:58 PM',
    updated_at: '2026-02-15 01:58 PM',
    history: [
      { date: 'Feb 27, 2026', time: '10:30 AM', activity: 'Arrived at FedEx Hub', location: 'Memphis, TN' },
      { date: 'Feb 26, 2026', time: '04:15 PM', activity: 'Departed FedEx Location', location: 'Dallas, TX' },
      { date: 'Feb 26, 2026', time: '09:00 AM', activity: 'Picked Up', location: 'Austin, TX' },
    ]
  }
};

const StaffSignIn = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    // For demo purposes, any login works
    navigate('/admin');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="text-center">
          <span className="text-4xl font-black tracking-tighter flex justify-center mb-6">
            <span className="text-[#4D148C]">Fed</span>
            <span className="text-[#FF6600]">Ex</span>
          </span>
          <h2 className="text-3xl font-black text-gray-900">Welcome to Fedex</h2>
          <p className="mt-2 text-sm text-gray-600">
            Staff Sign In to Fedex dashboard
          </p>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-2xl sm:rounded-3xl sm:px-10 border border-gray-100">
          <form className="space-y-6" onSubmit={handleSignIn}>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider">
                Email address
              </label>
              <div className="mt-1">
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="appearance-none block w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-[#4D148C] focus:border-[#4D148C] sm:text-sm transition-all"
                  placeholder="staff@fedex.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider">
                Password
              </label>
              <div className="mt-1">
                <input
                  required
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="appearance-none block w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-[#4D148C] focus:border-[#4D148C] sm:text-sm transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  className="h-4 w-4 text-[#4D148C] focus:ring-[#4D148C] border-gray-300 rounded"
                />
                <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                  Remember me
                </label>
              </div>

              <div className="text-sm">
                <a href="#" className="font-bold text-[#4D148C] hover:text-[#3a0f6a]">
                  Forgot password?
                </a>
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-4 px-4 border border-transparent rounded-xl shadow-lg text-lg font-black text-white bg-[#4D148C] hover:bg-[#3a0f6a] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#4D148C] transition-all"
              >
                Sign In
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

const AdminPage = () => {
  const navigate = useNavigate();
  const [shipments, setShipments] = useState<any[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [formData, setFormData] = useState({
    sender_name: '',
    sender_email: '',
    sender_phone: '',
    sender_address: '',
    recipient_name: '',
    recipient_email: '',
    recipient_phone: '',
    recipient_address: '',
    weight: '',
    shipping_cost: '',
    quantity: '1'
  });
  const [newTrackingId, setNewTrackingId] = useState('');

  useEffect(() => {
    fetchShipments();
  }, []);

  const fetchShipments = async () => {
    try {
      const res = await fetch('/api/admin/shipments');
      const data = await res.json();
      setShipments(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/shipments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      if (data.id) {
        setNewTrackingId(data.id);
        setIsCreating(false);
        setFormData({ 
          sender_name: '', 
          sender_email: '',
          sender_phone: '',
          sender_address: '', 
          recipient_name: '', 
          recipient_email: '',
          recipient_phone: '',
          recipient_address: '',
          weight: '',
          shipping_cost: '',
          quantity: '1'
        });
        fetchShipments();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const stats = [
    { label: 'Total Shipments', value: shipments.length, icon: <Package className="w-6 h-6" />, color: 'bg-purple-100 text-[#4D148C]' },
    { label: 'In Transit', value: shipments.filter(s => s.status === 'In Transit').length, icon: <Truck className="w-6 h-6" />, color: 'bg-blue-100 text-blue-600' },
    { label: 'Delivered', value: shipments.filter(s => s.status === 'Delivered').length, icon: <Shield className="w-6 h-6" />, color: 'bg-green-100 text-green-600' },
    { label: 'Pending', value: shipments.filter(s => s.status === 'Pending').length, icon: <Clock className="w-6 h-6" />, color: 'bg-orange-100 text-[#FF6600]' },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-72 bg-[#4D148C] text-white fixed h-full">
        <div className="p-8">
          <span className="text-3xl font-black tracking-tighter flex">
            <span className="text-white">Fed</span>
            <span className="text-[#FF6600]">Ex</span>
          </span>
          <p className="text-xs text-purple-300 font-bold mt-1 uppercase tracking-widest">Staff Portal</p>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: <Globe className="w-5 h-5" /> },
            { id: 'shipments', label: 'Shipments', icon: <List className="w-5 h-5" /> },
            { id: 'tracking', label: 'Tracking', icon: <Search className="w-5 h-5" /> },
            { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" /> },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center px-4 py-4 rounded-2xl font-bold transition-all ${
                activeTab === item.id ? 'bg-white text-[#4D148C] shadow-xl' : 'hover:bg-white/10 text-purple-100'
              }`}
            >
              <span className="mr-4">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-white/10">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center font-black">AD</div>
            <div className="ml-3">
              <p className="text-sm font-bold">Admin User</p>
              <p className="text-[10px] text-purple-300">admin@vesta.com</p>
            </div>
          </div>
          <button 
            onClick={() => navigate('/')}
            className="w-full flex items-center px-4 py-3 rounded-xl bg-red-500/20 text-red-200 hover:bg-red-500/30 transition-all font-bold text-sm"
          >
            <LogOut className="w-4 h-4 mr-3" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-72">
        {/* Top Header */}
        <header className="bg-white border-b border-gray-100 h-20 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center bg-gray-50 px-4 py-2 rounded-xl w-96">
            <Search className="w-4 h-4 text-gray-400 mr-3" />
            <input type="text" placeholder="Search shipments..." className="bg-transparent border-none outline-none text-sm w-full" />
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-400 hover:text-[#4D148C] transition-colors relative">
              <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
              <Clock className="w-6 h-6" />
            </button>
            <button 
              onClick={() => setIsCreating(true)}
              className="bg-[#FF6600] text-white px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-[#e65c00] transition-all shadow-lg shadow-orange-100 flex items-center"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Shipment
            </button>
          </div>
        </header>

        <div className="p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            {stats.map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm"
              >
                <div className={`${stat.color} w-12 h-12 rounded-2xl flex items-center justify-center mb-4`}>
                  {stat.icon}
                </div>
                <p className="text-gray-500 text-sm font-bold uppercase tracking-wider">{stat.label}</p>
                <h4 className="text-3xl font-black text-gray-900 mt-1">{stat.value}</h4>
              </motion.div>
            ))}
          </div>

          {newTrackingId && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-8 bg-green-500 text-white p-6 rounded-3xl flex items-center justify-between shadow-xl shadow-green-100"
            >
              <div className="flex items-center">
                <div className="bg-white/20 p-3 rounded-2xl mr-4">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-black text-lg">Shipment Created Successfully!</p>
                  <p className="text-green-100">Tracking ID: <span className="font-black underline">{newTrackingId}</span></p>
                </div>
              </div>
              <button onClick={() => setNewTrackingId('')} className="bg-white/20 p-2 rounded-xl hover:bg-white/30 transition-all">
                <X className="w-5 h-5" />
              </button>
            </motion.div>
          )}

          {/* Shipments Table */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center">
              <h2 className="text-xl font-black text-gray-900">Recent Shipments</h2>
              <button className="text-[#4D148C] font-bold text-sm flex items-center hover:underline">
                View All <ArrowRight className="ml-2 w-4 h-4" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-xs font-bold text-gray-400 uppercase tracking-widest border-b border-gray-50">
                    <th className="px-8 py-5">Tracking ID</th>
                    <th className="px-8 py-5">Sender</th>
                    <th className="px-8 py-5">Recipient</th>
                    <th className="px-8 py-5">Status</th>
                    <th className="px-8 py-5">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {shipments.map((s) => (
                    <tr key={s.id} className="hover:bg-gray-50 transition-colors group">
                      <td className="px-8 py-6">
                        <span className="font-black text-[#4D148C] group-hover:underline cursor-pointer">{s.id}</span>
                      </td>
                      <td className="px-8 py-6">
                        <p className="font-bold text-gray-900">{s.sender_name}</p>
                        <p className="text-xs text-gray-500">{s.sender_address}</p>
                      </td>
                      <td className="px-8 py-6">
                        <p className="font-bold text-gray-900">{s.recipient_name}</p>
                        <p className="text-xs text-gray-500">{s.recipient_address}</p>
                      </td>
                      <td className="px-8 py-6">
                        <span className={`text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-wider ${
                          s.status === 'Delivered' ? 'bg-green-100 text-green-700' : 
                          s.status === 'In Transit' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'
                        }`}>
                          {s.status}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-sm text-gray-500 font-medium">
                        {new Date(s.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      {/* Create Modal */}
      <AnimatePresence>
        {isCreating && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCreating(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="bg-[#4D148C] p-10 text-white relative">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32 blur-3xl" />
                <h2 className="text-3xl font-black relative z-10">Create New Shipment</h2>
                <p className="text-purple-200 mt-2 relative z-10">Enter the details to generate a new tracking ID</p>
                <button 
                  onClick={() => setIsCreating(false)} 
                  className="absolute top-8 right-8 bg-white/10 p-2 rounded-full hover:bg-white/20 transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <form onSubmit={handleCreate} className="p-10 space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Sender Information</label>
                    <input 
                      required
                      type="text" 
                      value={formData.sender_name}
                      onChange={(e) => setFormData({...formData, sender_name: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                      placeholder="Sender Full Name"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input 
                        type="email" 
                        value={formData.sender_email}
                        onChange={(e) => setFormData({...formData, sender_email: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                        placeholder="Sender Email"
                      />
                      <input 
                        type="text" 
                        value={formData.sender_phone}
                        onChange={(e) => setFormData({...formData, sender_phone: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                        placeholder="Sender Phone"
                      />
                    </div>
                    <input 
                      required
                      type="text" 
                      value={formData.sender_address}
                      onChange={(e) => setFormData({...formData, sender_address: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                      placeholder="Sender Address (City, State)"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Recipient Information</label>
                    <input 
                      required
                      type="text" 
                      value={formData.recipient_name}
                      onChange={(e) => setFormData({...formData, recipient_name: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                      placeholder="Recipient Full Name"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input 
                        type="email" 
                        value={formData.recipient_email}
                        onChange={(e) => setFormData({...formData, recipient_email: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                        placeholder="Recipient Email"
                      />
                      <input 
                        type="text" 
                        value={formData.recipient_phone}
                        onChange={(e) => setFormData({...formData, recipient_phone: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                        placeholder="Recipient Phone"
                      />
                    </div>
                    <input 
                      required
                      type="text" 
                      value={formData.recipient_address}
                      onChange={(e) => setFormData({...formData, recipient_address: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                      placeholder="Recipient Address (City, State)"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 border-t border-gray-50 pt-8">
                  <div className="space-y-3">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Package Weight (lbs)</label>
                    <input 
                      required
                      type="text" 
                      value={formData.weight}
                      onChange={(e) => setFormData({...formData, weight: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                      placeholder="e.g. 5.4"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Quantity</label>
                    <input 
                      required
                      type="number" 
                      value={formData.quantity}
                      onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                      placeholder="e.g. 1"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Shipping Cost ($)</label>
                    <input 
                      required
                      type="number" 
                      step="0.01"
                      value={formData.shipping_cost}
                      onChange={(e) => setFormData({...formData, shipping_cost: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 outline-none focus:border-[#4D148C] focus:bg-white transition-all text-sm font-medium"
                      placeholder="e.g. 45.50"
                    />
                  </div>
                </div>
                
                <div className="pt-4">
                  <button 
                    type="submit"
                    className="w-full bg-[#FF6600] text-white py-5 rounded-2xl font-black text-xl hover:bg-[#e65c00] transition-all shadow-xl shadow-orange-200 flex items-center justify-center"
                  >
                    <Package className="w-6 h-6 mr-3" />
                    GENERATE TRACKING ID
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Hero = () => {
  const [trackingId, setTrackingId] = useState('');
  const [isTracking, setIsTracking] = useState(false);
  const [trackingResult, setTrackingResult] = useState<TrackingStatus | null>(null);
  const [activeResultTab, setActiveResultTab] = useState<'status' | 'invoice' | 'map'>('status');
  const [error, setError] = useState('');

  const validateTrackingId = (id: string) => {
    if (!id) return 'Tracking ID is required';
    if (id.length < 10) return 'Tracking ID must be at least 10 characters';
    if (!/^[a-zA-Z0-9]+$/.test(id)) return 'Tracking ID must be alphanumeric';
    return '';
  };

  const handleTrack = async () => {
    const validationError = validateTrackingId(trackingId);
    if (validationError) {
      setError(validationError);
      setTrackingResult(null);
      return;
    }
    
    setError('');
    setIsTracking(true);
    
    try {
      const res = await fetch(`/api/shipments/${trackingId}`);
      if (res.ok) {
        const data = await res.json();
        setTrackingResult(data);
      } else {
        // Fallback or error
        setError('Tracking ID not found in our system.');
        setTrackingResult(null);
      }
    } catch (err) {
      setError('An error occurred while tracking.');
    } finally {
      setIsTracking(false);
    }
  };

  return (
    <div className="relative bg-[#4D148C] overflow-hidden py-24 lg:py-32">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://picsum.photos/1920/1080?grayscale')] bg-cover bg-center" />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center lg:text-left lg:flex lg:items-center lg:justify-between">
          <div className="lg:w-1/2">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl sm:text-6xl font-black text-white leading-tight tracking-tight"
            >
              Where now meets <span className="text-[#FF6600]">next.</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mt-6 text-xl text-gray-200 max-w-2xl"
            >
              Track your shipments, explore our services, and find solutions for all your shipping and logistics needs.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-10 bg-white p-2 rounded-2xl shadow-2xl max-w-xl mx-auto lg:mx-0"
            >
              <div className="flex flex-col sm:flex-row items-center">
                <div className="flex-1 w-full px-4 py-3 flex items-center">
                  <Search className="text-gray-400 w-5 h-5 mr-3" />
                  <input 
                    type="text" 
                    value={trackingId}
                    onChange={(e) => {
                      setTrackingId(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder="Enter Tracking ID (e.g. 123456789012)" 
                    className="w-full outline-none text-gray-700 font-medium"
                  />
                </div>
                <button 
                  onClick={handleTrack}
                  disabled={isTracking}
                  className="w-full sm:w-auto bg-[#FF6600] text-white px-8 py-4 rounded-xl font-bold hover:bg-[#e65c00] transition-all disabled:opacity-50 flex items-center justify-center"
                >
                  {isTracking ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                      className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                    />
                  ) : 'TRACK'}
                </button>
              </div>
            </motion.div>

            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-2 text-red-400 text-sm font-bold text-left ml-4"
                >
                  {error}
                </motion.p>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {trackingResult && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="mt-12 relative max-w-2xl mx-auto"
                >
                  {/* Timeline Line */}
                  <div className="absolute left-4 top-0 bottom-0 w-1 bg-blue-600/30 z-0" />

                  <div className="space-y-8 relative z-10">
                    {activeResultTab === 'status' ? (
                      <>
                        {/* Sender Card */}
                        <div className="flex items-start">
                          <div className="w-8 h-8 rounded-full bg-blue-600 border-4 border-white shadow-lg shrink-0 mt-6 z-20" />
                          <div className="ml-6 flex-1 bg-white rounded-3xl p-8 shadow-xl border border-gray-100 text-left">
                            <h4 className="text-blue-600 font-black text-xl mb-4">Sender</h4>
                            <div className="space-y-2 text-gray-700 font-medium">
                              <p><span className="text-gray-900">Name:</span> {trackingResult.sender_name}</p>
                              <p><span className="text-gray-900">Email:</span> {trackingResult.sender_email}</p>
                              <p><span className="text-gray-900">Phone:</span> <a href={`tel:${trackingResult.sender_phone}`} className="text-blue-600 underline">{trackingResult.sender_phone}</a></p>
                              <p><span className="text-gray-900">Address:</span> {trackingResult.sender_address}</p>
                              <p><span className="text-gray-900">Lat:</span> {trackingResult.sender_lat} | <span className="text-gray-900">Lng:</span> {trackingResult.sender_lng}</p>
                              <p><span className="text-gray-900">Branch ID:</span> {trackingResult.branch_id} | <span className="text-gray-900">Staff ID:</span> {trackingResult.staff_id}</p>
                            </div>
                          </div>
                        </div>

                        {/* Receiver Card */}
                        <div className="flex items-start">
                          <div className="w-8 h-8 rounded-full bg-blue-600 border-4 border-white shadow-lg shrink-0 mt-6 z-20" />
                          <div className="ml-6 flex-1 bg-white rounded-3xl p-8 shadow-xl border border-gray-100 text-left relative">
                            <h4 className="text-blue-600 font-black text-xl mb-4">Receiver</h4>
                            <div className="space-y-2 text-gray-700 font-medium">
                              <p><span className="text-gray-900">Name:</span> {trackingResult.recipient_name}</p>
                              <p><span className="text-gray-900">Email:</span> {trackingResult.recipient_email}</p>
                              <p><span className="text-gray-900">Phone:</span> <a href={`tel:${trackingResult.recipient_phone}`} className="text-blue-600 underline">{trackingResult.recipient_phone}</a></p>
                              <p><span className="text-gray-900">Address:</span> {trackingResult.recipient_address}</p>
                              <p><span className="text-gray-900">Lat:</span> {trackingResult.recipient_lat} | <span className="text-gray-900">Lng:</span> {trackingResult.recipient_lng}</p>
                              <p><span className="text-gray-900">Branch ID:</span> {trackingResult.branch_id} | <span className="text-gray-900">Staff ID:</span> {trackingResult.staff_id}</p>
                            </div>
                          </div>
                        </div>

                        {/* Status Card */}
                        <div className="flex items-start">
                          <div className="w-8 h-8 rounded-full bg-blue-600 border-4 border-white shadow-lg shrink-0 mt-6 z-20" />
                          <div className="ml-6 flex-1 bg-white rounded-3xl p-8 shadow-xl border border-gray-100 text-left flex justify-between items-center">
                            <div>
                              <h4 className="text-blue-600 font-black text-xl mb-2">Status</h4>
                              <p className="text-gray-900 font-bold text-lg">{trackingResult.status}</p>
                              <p className="text-gray-400 text-sm font-medium mt-1">Updated: {trackingResult.created_at || new Date().toLocaleString()}</p>
                            </div>
                            <button className="bg-[#FF6600] p-3 rounded-xl text-white hover:bg-[#e65c00] transition-all">
                              <ChevronUp className="w-6 h-6" />
                            </button>
                          </div>
                        </div>
                      </>
                    ) : activeResultTab === 'map' ? (
                      /* Map Card */
                      <div className="flex items-start">
                        <div className="w-8 h-8 rounded-full bg-blue-600 border-4 border-white shadow-lg shrink-0 mt-6 z-20" />
                        <div className="ml-6 flex-1 bg-white rounded-3xl p-8 shadow-xl border border-gray-100 text-left">
                          <div className="flex justify-between items-center mb-6">
                            <h4 className="text-blue-600 font-black text-xl">Shipment Route</h4>
                            <button 
                              onClick={() => setActiveResultTab('status')}
                              className="text-xs font-bold text-gray-400 hover:text-blue-600 transition-colors"
                            >
                              Back to Status
                            </button>
                          </div>
                          
                          <div className="relative h-64 bg-gray-50 rounded-2xl border border-gray-100 overflow-hidden mb-6">
                            {/* Stylized SVG Map Placeholder */}
                            <svg viewBox="0 0 800 400" className="w-full h-full opacity-20">
                              <path d="M150,150 Q400,50 650,250" fill="none" stroke="#4D148C" strokeWidth="2" strokeDasharray="8,4" />
                              <circle cx="150" cy="150" r="8" fill="#4D148C" />
                              <circle cx="650" cy="250" r="8" fill="#FF6600" />
                            </svg>
                            
                            {/* Overlay Markers */}
                            <div className="absolute inset-0 p-8 flex flex-col justify-between">
                              <div className="flex items-start space-x-3">
                                <div className="w-10 h-10 bg-[#4D148C] rounded-full flex items-center justify-center shadow-lg">
                                  <MapPin className="w-5 h-5 text-white" />
                                </div>
                                <div>
                                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Origin</p>
                                  <p className="text-xs font-bold text-gray-900">{trackingResult.sender_address}</p>
                                </div>
                              </div>
                              
                              <div className="flex items-start space-x-3 self-end text-right">
                                <div>
                                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Destination</p>
                                  <p className="text-xs font-bold text-gray-900">{trackingResult.recipient_address}</p>
                                </div>
                                <div className="w-10 h-10 bg-[#FF6600] rounded-full flex items-center justify-center shadow-lg">
                                  <MapPin className="w-5 h-5 text-white" />
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
                              <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Distance</p>
                              <p className="text-sm font-black text-blue-900">~1,240 km</p>
                            </div>
                            <div className="p-4 bg-orange-50 rounded-2xl border border-orange-100">
                              <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest mb-1">Est. Time</p>
                              <p className="text-sm font-black text-orange-900">2 Days</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Invoice Card */
                      <div className="flex items-start">
                        <div className="w-8 h-8 rounded-full bg-blue-600 border-4 border-white shadow-lg shrink-0 mt-6 z-20" />
                        <div className="ml-6 flex-1 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
                          {/* Invoice Header */}
                          <div className="bg-[#4D148C] p-6 flex justify-between items-center">
                            <div className="flex flex-col">
                              <span className="text-white font-black text-2xl tracking-tighter">Fed<span className="text-[#FF6600]">Ex</span></span>
                              <span className="text-white/80 text-[10px] font-bold uppercase tracking-widest leading-none">Express</span>
                            </div>
                            <button 
                              onClick={() => setActiveResultTab('status')}
                              className="text-white/60 hover:text-white transition-colors"
                            >
                              <X className="w-6 h-6" />
                            </button>
                          </div>

                          <div className="p-8 space-y-8 text-left">
                            {/* Sender Section */}
                            <section>
                              <h5 className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-3">Sender</h5>
                              <div className="space-y-1">
                                <p className="text-gray-900 font-black text-lg">{trackingResult.sender_name}</p>
                                <p className="text-gray-600 text-sm">{trackingResult.sender_address}</p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Email:</span> <span className="text-gray-600">{trackingResult.sender_email}</span></p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Phone:</span> <a href={`tel:${trackingResult.sender_phone}`} className="text-blue-600 underline">{trackingResult.sender_phone}</a></p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Latitude / Longitude:</span> <span className="text-gray-600">{trackingResult.sender_lat} / {trackingResult.sender_lng}</span></p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Branch / Staff ID:</span> <span className="text-gray-600">{trackingResult.branch_id} / {trackingResult.staff_id}</span></p>
                              </div>
                            </section>

                            {/* Receiver Section */}
                            <section>
                              <h5 className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-3">Receiver</h5>
                              <div className="space-y-1">
                                <p className="text-gray-900 font-black text-lg">{trackingResult.recipient_name}</p>
                                <p className="text-gray-600 text-sm"><span className="font-bold text-gray-900">Address:</span> {trackingResult.recipient_address}</p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Email:</span> <span className="text-gray-600">{trackingResult.recipient_email}</span></p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Phone:</span> <a href={`tel:${trackingResult.recipient_phone}`} className="text-blue-600 underline">{trackingResult.recipient_phone}</a></p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Latitude / Longitude:</span> <span className="text-gray-600">{trackingResult.recipient_lat} / {trackingResult.recipient_lng}</span></p>
                                <p className="text-sm"><span className="font-bold text-gray-900">Branch / Staff ID:</span> <span className="text-gray-600">{trackingResult.branch_id} / </span></p>
                              </div>
                            </section>

                            {/* Tracking Info Section */}
                            <section className="bg-gray-50 -mx-8 px-8 py-6 space-y-2">
                              <h5 className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-3">Tracking Info</h5>
                              <p className="text-sm"><span className="font-bold text-gray-900">Tracking Code:</span> <span className="text-gray-600">{trackingResult.id}</span></p>
                              <p className="text-sm"><span className="font-bold text-gray-900">Current Latitude / Longitude:</span> <span className="text-gray-600">/</span></p>
                              <p className="text-sm flex items-center">
                                <span className="font-bold text-gray-900 mr-2">Status:</span> 
                                <span className="text-gray-600">{trackingResult.status}</span>
                              </p>
                              <p className="text-sm"><span className="font-bold text-gray-900">Last Location Update:</span> <span className="text-gray-600">{new Date().toISOString().split('T')[0]} 12:58 PM</span></p>
                              <p className="text-sm"><span className="font-bold text-gray-900">Created At:</span> <span className="text-gray-600">{trackingResult.created_at?.split(' ')[0]} 01:58 PM</span></p>
                              <p className="text-sm"><span className="font-bold text-gray-900">Updated At:</span> <span className="text-gray-600">{trackingResult.updated_at?.split(' ')[0]} 01:58 PM</span></p>
                              <div className="flex items-center pt-2">
                                <span className="font-bold text-gray-900 text-sm mr-3">Payment Status:</span>
                                <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${trackingResult.payment_status === 'Unpaid' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                  {trackingResult.payment_status || 'Unpaid'}
                                </span>
                              </div>
                            </section>

                            {/* Invoice Table */}
                            <div className="border border-gray-100 rounded-xl overflow-hidden">
                              <table className="w-full text-sm">
                                <thead className="bg-gray-50 border-b border-gray-100">
                                  <tr>
                                    <th className="px-4 py-3 text-left font-black text-gray-900">Type</th>
                                    <th className="px-4 py-3 text-center font-black text-gray-900">Qty</th>
                                    <th className="px-4 py-3 text-right font-black text-gray-900">Amount</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-50">
                                  <tr>
                                    <td className="px-4 py-4 text-gray-600 font-medium">{trackingResult.service_type || 'FedEx Priority Overnight'}</td>
                                    <td className="px-4 py-4 text-center text-gray-600 font-medium">{trackingResult.quantity || 1}</td>
                                    <td className="px-4 py-4 text-right text-gray-900 font-black">${trackingResult.shipping_cost?.toFixed(2)}</td>
                                  </tr>
                                  <tr className="bg-gray-50">
                                    <td colSpan={2} className="px-4 py-4 text-right font-black text-gray-900">Total</td>
                                    <td className="px-4 py-4 text-right font-black text-gray-900 text-lg">${trackingResult.shipping_cost?.toFixed(2)}</td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>

                            <div className="flex flex-col items-center space-y-4 pt-4">
                              <p className="text-[10px] font-bold text-gray-400">fed.byvesta.com</p>
                              <button className="w-full bg-[#7C69EF] text-white py-4 rounded-2xl font-black text-sm hover:bg-[#6a56d6] transition-all flex items-center justify-center shadow-xl">
                                <Printer className="w-5 h-5 mr-3" />
                                Print Invoice
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Footer Button */}
                  <div className="mt-12 flex flex-col items-center space-y-4">
                    {activeResultTab === 'status' && (
                      <div className="flex flex-wrap justify-center gap-4">
                        <button 
                          onClick={() => setActiveResultTab('map')}
                          className="bg-blue-600 text-white px-8 py-4 rounded-full font-black text-lg shadow-2xl hover:bg-blue-700 transition-all flex items-center"
                        >
                          <MapIcon className="w-5 h-5 mr-3" />
                          View Route Map
                        </button>
                        <button 
                          onClick={() => setActiveResultTab('invoice')}
                          className="bg-[#7C69EF] text-white px-8 py-4 rounded-full font-black text-lg shadow-2xl hover:bg-[#6a56d6] transition-all flex items-center"
                        >
                          <Printer className="w-5 h-5 mr-3" />
                          View / Print Invoice
                        </button>
                      </div>
                    )}
                    
                    <button 
                      onClick={() => setTrackingResult(null)}
                      className="text-gray-400 hover:text-white transition-colors font-bold text-sm"
                    >
                      Clear Tracking Result
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <p className="mt-4 text-gray-300 text-sm font-medium">
              30+ Years Experiences in Courier Service
            </p>
          </div>
          
          <div className="hidden lg:block lg:w-5/12">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="absolute -inset-4 bg-white/10 rounded-full blur-3xl animate-pulse" />
              <img 
                src="https://picsum.photos/seed/shipping/800/600" 
                alt="Logistics" 
                className="rounded-3xl shadow-2xl relative z-10 border-4 border-white/10"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Services = () => {
  const services = [
    {
      title: "FedEx Express",
      desc: "Flagship time-definite service for urgent shipments. Most packages arrive within 1–3 business days.",
      icon: <Clock className="w-8 h-8 text-[#4D148C]" />,
      color: "bg-purple-50"
    },
    {
      title: "FedEx Ground",
      desc: "Cost-effective, day-definite delivery specifically for North America. Typically delivers within 1–5 business days.",
      icon: <Truck className="w-8 h-8 text-[#FF6600]" />,
      color: "bg-orange-50"
    },
    {
      title: "FedEx Freight",
      desc: "Designed for heavy or bulky shipments exceeding 150 lbs, handling Less-Than-Truckload (LTL) freight.",
      icon: <Package className="w-8 h-8 text-blue-600" />,
      color: "bg-blue-50"
    },
    {
      title: "FedEx Custom Critical",
      desc: "Dedicated to highly sensitive, high-value, or urgent shipments that require special handling.",
      icon: <Shield className="w-8 h-8 text-red-600" />,
      color: "bg-red-50"
    },
    {
      title: "FedEx Office",
      desc: "Professional printing, packing services, and 'Hold at Location' options for secure pick up or drop off.",
      icon: <Printer className="w-8 h-8 text-green-600" />,
      color: "bg-green-50"
    },
    {
      title: "Global Logistics",
      desc: "End-to-end supply chain solutions to help you manage your business across the globe with ease.",
      icon: <Globe className="w-8 h-8 text-indigo-600" />,
      color: "bg-indigo-50"
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-[#4D148C] font-bold tracking-widest uppercase text-sm mb-4">What We Serve</h2>
          <h3 className="text-4xl font-black text-gray-900">Comprehensive Shipping & Logistics Solutions</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              whileHover={{ y: -10 }}
              className="p-8 rounded-3xl border border-gray-100 hover:shadow-xl transition-all group"
            >
              <div className={`${service.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                {service.icon}
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h4>
              <p className="text-gray-600 leading-relaxed">
                {service.desc}
              </p>
              <button className="mt-6 text-[#4D148C] font-bold flex items-center hover:translate-x-2 transition-transform">
                Learn More <ArrowRight className="ml-2 w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section className="py-24 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex lg:items-center lg:space-x-16">
          <div className="lg:w-1/2 relative">
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-[#FF6600]/10 rounded-full blur-3xl" />
            <img 
              src="https://picsum.photos/seed/hub/800/800" 
              alt="FedEx Hub" 
              className="rounded-3xl shadow-2xl relative z-10"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl z-20 hidden sm:block">
              <p className="text-[#4D148C] font-black text-4xl">30+</p>
              <p className="text-gray-600 font-bold">Years of Experience</p>
            </div>
          </div>
          
          <div className="lg:w-1/2 mt-16 lg:mt-0">
            <h2 className="text-[#4D148C] font-bold tracking-widest uppercase text-sm mb-4">About Our Company</h2>
            <h3 className="text-4xl font-black text-gray-900 mb-6">Connecting people with goods, services and ideas</h3>
            <p className="text-gray-600 text-lg leading-relaxed mb-8">
              At FedEx, we believe that a connected world is a better world, and that belief guides everything we do. Our European network offers next-day service to hundreds of markets, powered by our world-class team.
            </p>
            
            <div className="space-y-6">
              {[
                { title: "Tour the Charles de Gaulle hub", desc: "Go behind-the-scenes at our largest European air hub." },
                { title: "Our People", desc: "FedEx is a world class company and, at its core, is all about people." },
                { title: "Company Information", desc: "The FedEx European network offers next-day service to hundreds of markets." }
              ].map((item, i) => (
                <div key={i} className="flex items-start">
                  <div className="bg-[#4D148C] p-2 rounded-lg mt-1">
                    <div className="w-2 h-2 bg-white rounded-full" />
                  </div>
                  <div className="ml-4">
                    <h4 className="font-bold text-gray-900">{item.title}</h4>
                    <p className="text-gray-500">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: "How can I track my package?",
      a: "You can enter your 12-digit tracking number on the FedEx Tracking page or right here on our homepage for real-time updates."
    },
    {
      q: "What does 'Delivery Exception' mean?",
      a: "This means an unexpected event is delaying your package. Common reasons include incorrect addresses, missing documentation, or weather delays."
    },
    {
      q: "Can I change the delivery address?",
      a: "Yes, but only the sender can authorize a full address change. However, as a recipient, you can use FedEx Delivery Manager to request that the package be held at a FedEx location."
    },
    {
      q: "What are the shipping hours?",
      a: "Shipping hours vary by location and service type. Generally, FedEx Express operates 24/7, while FedEx Office locations have specific retail hours."
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-[#4D148C] font-bold tracking-widest uppercase text-sm mb-4">FAQ</h2>
          <h3 className="text-4xl font-black text-gray-900">Frequently Asked Questions</h3>
        </div>
        
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div key={i} className="border border-gray-100 rounded-2xl overflow-hidden">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors"
              >
                <span className="font-bold text-gray-900">{faq.q}</span>
                <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${openIndex === i ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {openIndex === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="p-6 pt-0 text-gray-600 leading-relaxed border-t border-gray-50">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const testimonials = [
    {
      name: "Alex Branda",
      role: "E-commerce Owner",
      text: "I used FedEx Ground to ship ten large boxes of books and kitchenware during my cross-country move. The reliability is worth every penny.",
      image: "https://i.pravatar.cc/150?u=alex"
    },
    {
      name: "Md Demo Sarker",
      role: "Small Business Owner",
      text: "I realized two days before Christmas that I’d forgotten to send my nephew’s gift. I used FedEx 2Day and it arrived with hours to spare.",
      image: "https://i.pravatar.cc/150?u=demo"
    },
    {
      name: "Md Jisan",
      role: "Legal Consultant",
      text: "Sending legal documents from New York to London can be nerve-wracking, but FedEx International Priority has never let me down.",
      image: "https://i.pravatar.cc/150?u=jisan"
    }
  ];

  return (
    <section className="py-24 bg-[#4D148C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-[#FF6600] font-bold tracking-widest uppercase text-sm mb-4">Testimonials</h2>
          <h3 className="text-4xl font-black text-white">What our customers say</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <div key={i} className="bg-white/10 backdrop-blur-lg p-8 rounded-3xl border border-white/10">
              <p className="text-gray-200 italic mb-8 leading-relaxed">"{t.text}"</p>
              <div className="flex items-center">
                <img src={t.image} alt={t.name} className="w-12 h-12 rounded-full mr-4" />
                <div>
                  <h4 className="text-white font-bold">{t.name}</h4>
                  <p className="text-gray-400 text-sm">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div>
            <span className="text-3xl font-black tracking-tighter flex mb-6">
              <span className="text-white">Fed</span>
              <span className="text-[#FF6600]">Ex</span>
            </span>
            <p className="text-gray-400 leading-relaxed mb-8">
              FedEx Corporation is a global giant in transportation, e-commerce, and business services, known for its integrated logistics network.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Twitter, Linkedin, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="bg-white/5 p-3 rounded-xl hover:bg-[#FF6600] transition-colors">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-8">Quick Links</h4>
            <ul className="space-y-4 text-gray-400">
              <li><Link to="/" className="hover:text-[#FF6600] transition-colors">Home</Link></li>
              <li><a href="#" className="hover:text-[#FF6600] transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-[#FF6600] transition-colors">Service</a></li>
              <li><Link to="/staff" className="hover:text-[#FF6600] transition-colors">Staff Login</Link></li>
              <li><a href="#" className="hover:text-[#FF6600] transition-colors">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-8">Legal</h4>
            <ul className="space-y-4 text-gray-400">
              {['Terms of Service', 'Privacy Policy', 'Cookie Policy', 'Support', 'Shipping Rates'].map((item) => (
                <li key={item}>
                  <a href="#" className="hover:text-[#FF6600] transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-8">Get In Touch</h4>
            <ul className="space-y-4 text-gray-400">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 text-[#FF6600] mr-3 mt-1 shrink-0" />
                <span>FedEx Corporation P.O. Box 727 Memphis, TN 38194-1062</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-5 h-5 text-[#FF6600] mr-3 shrink-0" />
                <span>+18085633849</span>
              </li>
              <li className="flex items-center">
                <Mail className="w-5 h-5 text-[#FF6600] mr-3 shrink-0" />
                <span>insightwebmaster@fedex.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-12 border-t border-white/5 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} FedEx. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white font-sans selection:bg-[#FF6600] selection:text-white">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={
              <>
                <Hero />
                <Services />
                <About />
                <FAQ />
                <Testimonials />
              </>
            } />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="/staff" element={<StaffSignIn />} />
          </Routes>
        </main>
        <Footer />
        
        {/* Cookie Banner */}
        <div className="fixed bottom-6 left-6 right-6 md:left-auto md:w-96 bg-white rounded-2xl shadow-2xl border border-gray-100 p-6 z-[100] flex items-center justify-between">
          <p className="text-sm text-gray-600 mr-4">
            We use cookies to improve your experience. <a href="#" className="text-[#4D148C] font-bold underline">Read Policy</a>
          </p>
          <button className="bg-[#4D148C] text-white px-4 py-2 rounded-lg text-sm font-bold shrink-0">
            Accept
          </button>
        </div>
      </div>
    </Router>
  );
}
