import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import { db } from './firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Search, Printer, X } from 'lucide-react';
import './index.css';

const TrackApp = () => {
  const [id, setId] = useState('');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleTrack = async () => {
    if (!id) return;
    setLoading(true);
    setError('');
    try {
      // READ from Firebase Database
      const q = query(collection(db, "shipments"), where("trackingId", "==", id));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        setResult(querySnapshot.docs[0].data());
      } else {
        setError("Shipment not found.");
        setResult(null);
      }
    } catch (err) {
      console.error(err);
      setError("Database error.");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#4D148C] p-8 flex flex-col items-center">
      <div className="w-full max-w-xl">
        <h1 className="text-4xl font-black text-white mb-8 text-center">Track Shipment</h1>
        
        <div className="bg-white p-2 rounded-2xl shadow-2xl flex items-center mb-4">
          <Search className="text-gray-400 w-6 h-6 mx-4" />
          <input 
            className="flex-1 p-4 outline-none text-lg font-medium"
            placeholder="Enter Tracking ID"
            value={id}
            onChange={e => setId(e.target.value)}
          />
          <button 
            onClick={handleTrack}
            disabled={loading}
            className="bg-[#FF6600] text-white px-8 py-4 rounded-xl font-bold hover:bg-[#e65c00] transition-all disabled:opacity-50"
          >
            {loading ? '...' : 'TRACK'}
          </button>
        </div>

        {error && <p className="text-red-400 font-bold text-center">{error}</p>}

        {result && (
          <div className="mt-8 bg-white rounded-3xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4">
            <div className="bg-[#4D148C] p-6 flex justify-between items-center">
              <span className="text-white font-black text-2xl">FedEx Invoice</span>
              <button onClick={() => setResult(null)} className="text-white/60"><X /></button>
            </div>
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Sender</h5>
                  <p className="font-bold text-gray-900">{result.sender_name}</p>
                  <p className="text-sm text-gray-600">{result.sender_address}</p>
                </div>
                <div>
                  <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Receiver</h5>
                  <p className="font-bold text-gray-900">{result.recipient_name}</p>
                  <p className="text-sm text-gray-600">{result.recipient_address}</p>
                </div>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-2xl">
                <p className="text-sm mb-1"><span className="font-bold">Status:</span> {result.status}</p>
                <p className="text-sm"><span className="font-bold">Tracking Code:</span> {result.trackingId}</p>
              </div>

              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-3 text-left">Type</th>
                    <th className="p-3 text-center">Qty</th>
                    <th className="p-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t border-gray-100">
                    <td className="p-3">Priority Shipping</td>
                    <td className="p-3 text-center">{result.quantity}</td>
                    <td className="p-3 text-right font-black">${result.shipping_cost}</td>
                  </tr>
                </tbody>
              </table>

              <button className="w-full bg-[#7C69EF] text-white py-4 rounded-2xl font-black flex items-center justify-center">
                <Printer className="w-5 h-5 mr-3" /> Print Invoice
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')!).render(<TrackApp />);
